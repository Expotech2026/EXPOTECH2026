import type { Route } from './+types/home';
import { seo } from '@/lib/seo';
import { Portal } from '@/components/home/portal';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Feira de Expições | Plataforma de gestão',
		description: 'Plataforma de gestão da feira de exposições para alunos, orientadores, avaliadores e administradores.',
	});
}

export default function HomePage() {
	return <Portal />;
}
